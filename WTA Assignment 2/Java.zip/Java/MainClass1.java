package javaPrgm;

public class MainClass1 {

}
